-- This section handles initial setup and loads resources.
function love.load()
    -- Load necessary libraries and game objects
    Object = require "classic"
    require "snake"
    require "enemy"

    -- Load images and get their dimensions
    image = love.graphics.newImage("black.png")
    width = image:getWidth()
    height = image:getHeight()

    -- Initialize tilemap with default values
    tilemap = {}
    for i = 0, 33 do
        tilemap[i] = {}
        for j = 0, 34 do
            tilemap[i][j] = 1
        end
    end

    -- Load color images and start page image
    colors = {
        love.graphics.newImage("black.png"),
        love.graphics.newImage("green.png"),
        love.graphics.newImage("grey.png"),
        love.graphics.newImage("pink.png")
    }
    startPageImage = love.graphics.newImage("start_page.png")
    startPageVisible = true

    -- Set window mode to match start page dimensions
    love.window.setMode(startPageImage:getWidth(), startPageImage:getHeight())

    -- Initialize game variables
    gameOver = false
    snakeLength = 0
    highestScore = 0

    -- Load fonts
    font = love.graphics.newFont("path_to_your_pixel_font.ttf", 36)
    love.graphics.setFont(font)
    gameOverFont = love.graphics.newFont("path_to_your_pixel_font.ttf", 72)

    -- Initialize snake, enemies, and food positions
    s1 = Snake(2, 2, width, height, 0)
    enemies = {}
    number = 1
    enemySpawned = false
    a = 5
    b = 8
    tilemap[a][b] = 2
end

-- This function checks for collision with food.
function checkcollision(dt, player_x, player_y)
    local target_tile = tilemap[player_y + 1][player_x + 1] -- Adjust for 0-based indexing

    if target_tile == 2 then
        s1:increaseSize()
        -- Find a new random position for tile with color number 2
        local new_x
        local new_y
        new_x = math.random(0, 30) -- Adjust for 0-based indexing
        new_y = math.random(0, 30) -- Adjust for 0-based indexing

        -- Reset the current tile to 1 (empty)
        tilemap[player_y + 1][player_x + 1] = 1 -- Adjust for 0-based indexing

        -- Set the new position of tile with color number 2
        tilemap[new_y + 1][new_x + 1] = 2 -- Adjust for 0-based indexing

        -- Update the position of 'a' and 'b' for reference
        a = new_y + 1
        b = new_x + 1  -- Adjust for 0-based indexing

        number = number + 1
        if number % 4 == 0 then
            enemySpawned = false
        end
        return true
    end
    return false
end

-- This function handles key presses.
function love.keypressed(key)
    if startPageVisible and key == "return" then
        startPageVisible = false  -- Hide start page
    elseif gameOver and key == "return" then
        resetgame()
    else
        s1:keypressed(key)  -- Handle key presses for the game
    end
end

-- This function resets the game state.
function resetgame()
        gameOver = false
        snakeLength = 0
        s1 = Snake(2, 2, width, height, 0)
        enemies = {}
        number = 1
        enemySpawned = false
        a = 5
        b = 8
    
        -- Reset tilemap
        tilemap = {}
        for i = 0, 33 do
            tilemap[i] = {}
            for j = 0, 34 do
                tilemap[i][j] = 1
            end
        end
        tilemap[a][b] = 2   -- Set initial position
    end

function overlap()
    
end

-- This function checks for game over conditions.
function gameOverCondition(dt)
    local ask = false
    if number >= 4 then
        for _, enemy in ipairs(enemies) do
            if enemy.tile_x == s1.tile_x and enemy.tile_y == s1.tile_y then
                return true
            end
            for i = #enemy.tail, 2, -1 do
                if s1.tile_x == enemy.tail[i].x and s1.tile_y == enemy.tail[i].y then
                     return true
                end
            end    
        end
     end
     for d = 0, 33 do
        ask = true
        for p = 0, 34 do
            if tilemap[d][p] == 1 then
                ask = false
                break
            end
        end
     end
     return ask
end

-- This function handles game updates.
function love.update(dt)
    if not gameOver then 
        checkcollision(dt, s1.tile_x, s1.tile_y)
        local target_tile = tilemap[s1.tile_y + 1][s1.tile_x + 1] -- Adjust for 0-based indexing
        if target_tile == 1 then
            tilemap[s1.tile_y + 1][s1.tile_x + 1] = 3
        end
        s1:update(dt)
        
        if number % 4 == 0 and not enemySpawned then
            local newEnemy = Enemy(2, 2, width, height, 1)
            for k = 0, 3 do
                newEnemy:increaseSize()
            end
            table.insert(enemies, newEnemy)
            enemySpawned = true
        end

        for _, enemy in ipairs(enemies) do
            enemy:update(dt)
        end

        if gameOverCondition(dt) then
            gameOver = true
            snakeLength = #s1.tail + 1
            highestScore = math.max(highestScore, snakeLength)
        end
    end
end

-- This function handles rendering.
function love.draw()
    if not startPageVisible then
        for i,row in ipairs(tilemap) do
            for j,tile in ipairs(row) do
                if tile ~= 0 then
                    love.graphics.draw(colors[tile], (j - 1) * width, (i - 1) * height)
                end 
            end
        end
        s1:draw()
        for _, enemy in ipairs(enemies) do
            enemy:draw()
        end
    end

    if gameOver then
        -- Draw a semi-transparent background
        love.graphics.setColor(0, 0, 0, 0.5)
        love.graphics.rectangle('fill', 0, 0, love.graphics.getWidth(), love.graphics.getHeight())

        -- Draw "Game Over" text
        love.graphics.setFont(gameOverFont)
        love.graphics.setColor(1, 0, 0)
        local gameOverText = "Game Over"
        local gameOverTextWidth = gameOverFont:getWidth(gameOverText)
        local gameOverTextHeight = gameOverFont:getHeight(gameOverText)
        love.graphics.printf(gameOverText, 0, love.graphics.getHeight()/3 - gameOverTextHeight/2, love.graphics.getWidth(), "center")

        -- Set the font and color for other text
        love.graphics.setFont(font)
        love.graphics.setColor(1, 1, 1)

        local lines = {
            "Snake Length: " .. snakeLength,
            "Highest Score: " .. highestScore,
            "Press Enter to Restart"
        }

        local lineHeight = 48
        local startY = love.graphics.getHeight()/2 - (#lines * lineHeight)/2

        for i, line in ipairs(lines) do
            local lineWidth = font:getWidth(line)
            love.graphics.printf(line, 0, startY + (i-1)*lineHeight, love.graphics.getWidth(), "center")
        end
    end

    if startPageVisible then
        love.graphics.draw(startPageImage, 0, 0)
    end
end

