Enemy = Object:extend()

function Enemy:new(x, y, w, h, n)
    tick = require "tick"
    drawRect = false
    tick.delay(function() drawRect = true end, 0)
    self.tile_x = x
    self.tile_y = y
    self.width = w
    self.height = h
    self.num = n
    self.tail = {}  -- Initialize tail table
    self.image_snake = love.graphics.newImage("red.png")
    delay = 8
    a = math.random(0, 30)
    b = math.random(0, 30)
    c = math.random(0, 25)
    d = math.random(0, 25)
end

function Enemy:update(dt)
    if delay > 0 then
        delay = delay - 1
        return
    end

    local x = self.tile_x
    local y = self.tile_y

    -- Move the tail segments
    if #self.tail > 0 then
        for i = #self.tail, 2, -1 do
            self.tail[i].x = self.tail[i - 1].x
            self.tail[i].y = self.tail[i - 1].y
        end
        self.tail[1].x = x
        self.tail[1].y = y
    end

    if x == a then
        self.num = 4
    elseif x == b then
        self.num = 3
    elseif y == c then
        self.num = 2
    elseif y == d then
        self.num = 1
    end

    -- Update the position of the head
    if self.num == 1 then
        x = x + 1
    elseif self.num == 2 then
        x = x - 1
    elseif self.num == 3 then
        y = y - 1
    elseif self.num == 4 then
        y = y + 1
    end

    if x < 0 then
        x = 33
    elseif x > 33 then
        x = 0
    end
    if y < 0 then
        y = 32
    elseif y > 32 then
        y = 0
    end

    self.tile_x = x
    self.tile_y = y
    delay = delay + 8
    tick.update(dt)
end


function Enemy:draw()
    if drawRect then
        love.graphics.draw(self.image_snake, self.tile_x * self.width, self.tile_y * self.height)

        -- Draw the tail segments
        for k, segment in ipairs(self.tail) do
            love.graphics.draw(self.image_snake, segment.x * self.width, segment.y * self.height)
        end
    end
end

function Enemy:increaseSize()
    local newSegment = {x = self.tile_x, y = self.tile_y}
    table.insert(self.tail, newSegment)
end

