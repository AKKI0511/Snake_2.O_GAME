-- Define the Snake class as an extension of the Object class.
Snake = Object:extend()

-- Initialize a new Snake object.
function Snake:new(x, y, w, h, n)
    tick = require "tick"
    drawRect = false
    tick.delay(function() drawRect = true end, 0)
    self.tile_x = x
    self.tile_y = y
    self.width = w
    self.height = h
    self.num = n
    self.tail = {}  -- Initialize tail table
    self.image_snake = love.graphics.newImage("white.png")
    delay = 8
end

-- Handle key presses to change the direction of the snake.
function Snake:keypressed(key)
    if key == "right" and self.num ~= 2 then
        self.num = 1
    end
    if key == "left" and self.num ~= 1 then
        self.num = 2
    end
    if key == "up" and self.num ~= 4 then
        self.num = 3
    end
    if key == "down" and self.num ~= 3 then
        self.num = 4
    end
end

-- Update the Snake's position and tail.
function Snake:update(dt)
    if delay > 0 then
        delay = delay - 1
        return
    end

    local x = self.tile_x
    local y = self.tile_y

    -- Move the tail segments
    if #self.tail > 0 then
        for i = #self.tail, 2, -1 do
            self.tail[i].x = self.tail[i - 1].x
            self.tail[i].y = self.tail[i - 1].y
            if x == self.tail[i].x and y == self.tail[i].y then
                love.load()
            end
        end
        self.tail[1].x = x
        self.tail[1].y = y
    end

    -- Update the position of the head
    if self.num == 1 then
        x = x + 1
    elseif self.num == 2 then
        x = x - 1
    elseif self.num == 3 then
        y = y - 1
    elseif self.num == 4 then
        y = y + 1
    end

    if x < 0 then
        x = 34
    elseif x > 34 then
        x = 0
    end
    if y < 0 then
        y = 32
    elseif y > 32 then
        y = 0
    end

    self.tile_x = x
    self.tile_y = y
    delay = delay + 8
    tick.update(dt)
end

-- Draw the Snake object on the screen.
function Snake:draw()
    if drawRect then
        love.graphics.draw(self.image_snake, self.tile_x * self.width, self.tile_y * self.height)

        -- Draw the tail segments
        for k, segment in ipairs(self.tail) do
            love.graphics.draw(self.image_snake, segment.x * self.width, segment.y * self.height)
        end
    end
end

-- Increase the size of the Snake's tail.
function Snake:increaseSize()
    local newSegment = {x = self.tile_x, y = self.tile_y}
    table.insert(self.tail, newSegment)
end
